<?php
$conn = new mysqli('localhost','root','','my_db','3307');
if ($conn->connect_error) {
    die('Error : ('. $conn->connect_errno .') '. $conn->connect_error);
}
?>